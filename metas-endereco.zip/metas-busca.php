<?php
/*
Plugin Name: Adicionar endereço fictício no pedido
Description: Este plugin adiciona um endereço fictício em um pedido do WooCommerce quando o status do pedido é alterado para "processando".
Version: 1.0
Author: Seu Nome
*/

add_action( 'woocommerce_order_status_processing', 'adicionar_endereco_aleatorio', 10, 2 );

function adicionar_endereco_aleatorio( $order_id, $order ) {
    // Verifica se o endereço de faturamento já foi preenchido
    $billing_address = $order->get_address('billing');
    if ( ! $billing_address['first_name'] || ! $billing_address['last_name'] || ! $billing_address['address_1'] || ! $billing_address['city'] || ! $billing_address['state'] || ! $billing_address['postcode'] || ! $billing_address['country'] ) {
        // Instancia a classe de países do WooCommerce
        $wc_countries = new WC_Countries();
        // Obtém as informações do país de destino
        $dest_country = $order->get_shipping_country();
        // Obtém o estado do país de destino
        $dest_state = $order->get_shipping_state();
        // Obtém as cidades do país de destino
        $dest_cities = $wc_countries->get_cities( $dest_country, $dest_state );
        // Define o endereço aleatório para o faturamento
        $endereco = array(
            'first_name' => 'Nome Aleatório',
            'last_name' => 'Sobrenome Aleatório',
            'company' => '',
            'email' => $order->get_billing_email(),
            'phone' => $order->get_billing_phone(),
            'address_1' => 'Endereço Aleatório, ' . rand(1, 999),
            'address_2' => '',
            'city' => $dest_cities[array_rand($dest_cities)],
            'state' => $dest_state,
            'postcode' => rand(10000, 99999) . '-' . rand(1000, 9999),
            'country' => $dest_country
        );
        // Define o endereço aleatório para o faturamento do pedido
        $order->set_address( $endereco, 'billing' );
        // Atualiza o pedido
        $order->save();
    }
}
?>