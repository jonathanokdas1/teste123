# Procedures

Procedures for Geocoder contributors.

- [Provider Deprecation](provider-deprecation.md)