# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release.

## 4.1.0

### Removed

- Drop support for PHP < 7.2

## 4.0.1

Final release of this provider due to the service shutting down. Please see the main readme.

## 4.0.0

First release of this library. 
